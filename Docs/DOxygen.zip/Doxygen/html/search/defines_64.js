var searchData=
[
  ['default_5fdb_5fpath',['DEFAULT_DB_PATH',['../_door_bot_8h.html#a7b9d4fe3f3090d5617cdc86cb250e776',1,'DoorBot.h']]]
];
