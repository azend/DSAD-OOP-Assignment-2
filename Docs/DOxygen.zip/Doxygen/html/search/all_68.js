var searchData=
[
  ['haschangedsincelastsave',['HasChangedSinceLastSave',['../class_member_store.html#a40c0a26df6412449eda217ac5b8dddc0',1,'MemberStore']]]
];
