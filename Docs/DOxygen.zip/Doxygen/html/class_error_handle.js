var class_error_handle =
[
    [ "ErrorHandle", "class_error_handle.html#a0b69ed94c76cbdc47f1ab29848719297", null ],
    [ "ErrorHandle", "class_error_handle.html#a304e759c1c69eb8d3a3a414cdfed43f7", null ],
    [ "ClearErrorLog", "class_error_handle.html#a3b088f81998a7d44b29f2719b4564157", null ],
    [ "GetErrorLevel", "class_error_handle.html#acc85f1ed94b31b9f33cc03a09d4165cd", null ],
    [ "SetErrorLevel", "class_error_handle.html#afb28a0a8171c02092da9d88b923ec304", null ],
    [ "WriteToErrorLog", "class_error_handle.html#a7b347f35df296bec96c09ec09ad0a1b7", null ]
];