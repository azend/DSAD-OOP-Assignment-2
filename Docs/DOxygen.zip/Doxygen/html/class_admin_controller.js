var class_admin_controller =
[
    [ "AdminController", "class_admin_controller.html#ab4789bf3cc909d5276a3300a751bb9a8", null ],
    [ "AdminController", "class_admin_controller.html#a4fcdc55468fd6846eddd800c2cce512d", null ],
    [ "AddTonsOfUsers", "class_admin_controller.html#a5a24dab1184055bb633c4ffbca28f326", null ],
    [ "AddUser", "class_admin_controller.html#a686239f62a696d7f2f2222dc76c84423", null ],
    [ "DeleteSET", "class_admin_controller.html#ab82ad035b10eb384872f4116e6a4b4fe", null ],
    [ "DeleteUser", "class_admin_controller.html#a1d43e86e1c7f36cc4f864cd67284a59a", null ],
    [ "DisplayUser", "class_admin_controller.html#ab84dbf4b2ebb12eb24b7efac846baf43", null ],
    [ "SaveSETToFile", "class_admin_controller.html#a5a0d75a4f63ed878903dc4790d6b2b51", null ]
];