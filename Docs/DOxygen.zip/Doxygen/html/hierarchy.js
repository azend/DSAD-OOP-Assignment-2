var hierarchy =
[
    [ "DoorBot", "class_door_bot.html", null ],
    [ "map", null, [
      [ "MemberStore", "class_member_store.html", null ]
    ] ],
    [ "Member", "class_member.html", null ]
];