var class_member_reader =
[
    [ "MemberReader", "class_member_reader.html#a6e74189949166e75d521df69cc989bec", null ],
    [ "~MemberReader", "class_member_reader.html#afbac8358432444290d70c7c41ac09447", null ],
    [ "operator>>", "class_member_reader.html#a968cea864430527d24e0e7610d9c0453", null ]
];