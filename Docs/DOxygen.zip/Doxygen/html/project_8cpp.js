var project_8cpp =
[
    [ "AddMember", "project_8cpp.html#a67122690f954034ba8bc70e24b22d6f1", null ],
    [ "AskYesNoConfirmation", "project_8cpp.html#ad7878125c8138081bd1d66db40034138", null ],
    [ "CarloSpecial", "project_8cpp.html#ac2688b530582d95b84d944d6e24da7f6", null ],
    [ "clearScreen", "project_8cpp.html#a9d7e8af417b6d543da691e9c0e2f6f9f", null ],
    [ "DeleteMember", "project_8cpp.html#a6495a5b31bdeabc2e55c844f07fa4108", null ],
    [ "EraseDatabase", "project_8cpp.html#a64cf401a9a9edf82e55b0b20d59cf07e", null ],
    [ "ExitDiscardingChanges", "project_8cpp.html#a7b02525ab3edd6f11d8a43d17a44631a", null ],
    [ "ExitSavingChanges", "project_8cpp.html#ad10858b0f64ede0fcf7361f0a7bf9325", null ],
    [ "GetAllMembers", "project_8cpp.html#ab8df6e52efc83f48a14a29fd2f0c8670", null ],
    [ "LoadDatabase", "project_8cpp.html#aa5ee61ce01a6bbe96a4374704002e42c", null ],
    [ "main", "project_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "pause", "project_8cpp.html#a7167f5c196fc5e167bfabde1a730e81d", null ],
    [ "StoreDatabase", "project_8cpp.html#ac9ccf340d989e1b66b3f2e8d25d6f668", null ],
    [ "ViewMember", "project_8cpp.html#abf595762c537e82efa878f1a8bde4b58", null ]
];